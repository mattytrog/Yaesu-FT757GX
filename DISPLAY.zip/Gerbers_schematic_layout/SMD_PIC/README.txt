The gerbers are the same, apart from the OEM does NOT have a built-in PIC flashing header and is meant for people who require pre-built units.

The DIY gerber has a Pickit 3 compatible programming header. There is also a little solder jumper to apply once programming is complete.